package com.datmt.keycloak.springbootauth.service;

public interface EmailSenderService {
    void sendEmail ( String toward , String subject , String message );


}
