package com.datmt.keycloak.springbootauth.Validator;

import com.datmt.keycloak.springbootauth.DTO.CategoryDTO;
import com.datmt.keycloak.springbootauth.DTO.OrganisateurDTO;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class OrganisateurValidator {

}
