package com.datmt.keycloak.springbootauth.Model;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;


    private String eventName;


    private String description;


    private Date createdDate;


    private LocalDate startDate;

    private LocalDate endDate;

    private String type;

    private Boolean started;


    private Boolean finished;


    private String picture;


    private Boolean deleted;


    private Boolean reported;


    private Boolean canceled;

    @OneToMany
    private List<User> users;

    @ManyToOne
    private Location location;
    @ManyToOne
    private Category category;

    @ManyToOne
    private Organisateur organisateur ;

    @ManyToMany
    private List<Event> events;

}