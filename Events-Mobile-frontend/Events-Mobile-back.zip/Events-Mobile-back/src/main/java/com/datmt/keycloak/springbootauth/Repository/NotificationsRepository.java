package com.datmt.keycloak.springbootauth.Repository;

import com.datmt.keycloak.springbootauth.Model.Notifications;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface NotificationsRepository extends JpaRepository<Notifications, Long> {
    Optional<Notifications> findNotificationsByUser_Id (String id);
    Optional<Notifications> findNotificationsByEvent_Id (Long id);
    Optional<Notifications> findNotificationsByUser_IdAndEvent_IdAndSolved(String id , Long idEvent, Boolean solved);
    List<Notifications> findAllByUser_Id(String id);
    List<Notifications> findAllByOrg_Id(String id);
    Optional<Notifications> findNotificationsByUser_IdAndEvent_IdAndAccepted(String id , Long Event, Boolean accepted);
    Integer countNotificationsByUser_IdAndEvent_IdAndOrg_Id(String id , Long Event , String orgId);

}
