package com.datmt.keycloak.springbootauth.http.requests;

import lombok.Getter;

@Getter
public class RefreshT {
    String ref;
}
