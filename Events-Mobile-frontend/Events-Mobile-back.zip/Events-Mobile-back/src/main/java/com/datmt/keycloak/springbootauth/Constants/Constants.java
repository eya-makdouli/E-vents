package com.datmt.keycloak.springbootauth.Constants;

public interface Constants {
    public static  String APP_ROOT ="api/v1";
}
