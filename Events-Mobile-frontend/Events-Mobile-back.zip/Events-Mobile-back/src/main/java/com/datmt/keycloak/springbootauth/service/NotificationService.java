package com.datmt.keycloak.springbootauth.service;

import com.datmt.keycloak.springbootauth.DTO.NotificationsDTO;

import java.util.List;
import java.util.Optional;

public interface NotificationService {

    NotificationsDTO save (NotificationsDTO notificationsDTO);

    NotificationsDTO findById(Long id);

    Optional<NotificationsDTO> findNotificationsByUser_Id(String id);

    List<NotificationsDTO> findNotificationsByEvent_Id(Long id);

    NotificationsDTO updateNotification(Long id,NotificationsDTO notificationsDTO);

    List<NotificationsDTO> findAll();

    NotificationsDTO findNotificationsByUser_IdAndEvent_IdAndSolved(String id , Long idEvent, Boolean solved);
   NotificationsDTO findNotificationsByUser_IdAndEvent_IdAndAccepted(String id , Long Event, Boolean accepted);
    void delete(Long id);

    List<NotificationsDTO> findAllByUser_Id(String id);
    List<NotificationsDTO> findAllByOrg_Id(String id);

    Integer findNotificationsByUser_IdAndEvent_IdAndOrg_Id(String id , Long Event , String orgId);

}
