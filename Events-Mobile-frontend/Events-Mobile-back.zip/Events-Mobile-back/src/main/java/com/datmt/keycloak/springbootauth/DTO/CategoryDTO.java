package com.datmt.keycloak.springbootauth.DTO;

import com.datmt.keycloak.springbootauth.Model.Category;

import lombok.Builder;
import lombok.Data;

import java.util.List;


@Data
@Builder
public class CategoryDTO {
    private Long id;
    private String genre;
    private String icon;
   // private List<Event> events;


    public static CategoryDTO fromEntity(Category category){
        if(category == null){
            return null;
        }
        return CategoryDTO.builder().id(category.getId())
                .genre(category.getGenre())
                .icon(category.getIcon())
            //    .events(category.getEvents())
                .build();
    }

    public static Category toEntity(CategoryDTO categoryDTO) {
        if (categoryDTO == null) {
            return null;
        }
        Category category = new Category();
        category.setId(categoryDTO.getId());
        category.setGenre(categoryDTO.getGenre());
        category.setIcon(categoryDTO.getIcon());
      //  category.setEvents(categoryDTO.getEvents());

        return category;
    }

}
