package com.datmt.keycloak.springbootauth.service;

import com.datmt.keycloak.springbootauth.DTO.LocationDTO;
import com.datmt.keycloak.springbootauth.Model.Location;

import java.util.List;
import java.util.Optional;

public interface LocationService {
        LocationDTO save (LocationDTO locationDTO);

        LocationDTO findById(Long idLocation);

        LocationDTO findLocationByCity(String City);

        LocationDTO findLocationByCountry(String county);
        LocationDTO findLocationByName(String name);
        LocationDTO findLocationByZipCode(String zipcode);

        LocationDTO findLocationByRegion (String region);

        List<LocationDTO> findAll();

        void delete(Long idLocation);
        List<LocationDTO> findAllByCityLike(String citylike);
    }


